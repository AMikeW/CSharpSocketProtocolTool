﻿public static class DefaultVar
{
    public const string STRING = "";
    public const int INT32 = 0;
    public const float FLOAT = 0.0f;
    public const double DOUBLE = 0.00f;
    public const char CHAR = '0';
    public static ClassBase CLASS = new ClassBase();
}