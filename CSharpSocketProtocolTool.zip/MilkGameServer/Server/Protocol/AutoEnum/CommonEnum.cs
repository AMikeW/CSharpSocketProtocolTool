public enum ProtocolNo
{
    LoginProtocolData = 1,
}
public enum ProtocolEventType
{
    Null,
    LoginProtocolData = 1,
}
public enum DataID
{
    User = 1,
    Student = 3,
}
